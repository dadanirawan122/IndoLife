<?php

namespace App\Models\Billing;

class Qris {
    public function processPayment($data) {
        // Logika untuk memproses pembayaran QRIS
    }
}
