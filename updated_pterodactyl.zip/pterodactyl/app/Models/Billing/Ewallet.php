<?php

namespace App\Models\Billing;

class Ewallet {
    public function processPayment($data) {
        // Logika untuk memproses pembayaran e-wallet
    }
}
