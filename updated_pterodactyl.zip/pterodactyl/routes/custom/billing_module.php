<?php

use App\Models\Billing\Qris;
use App\Models\Billing\Ewallet;
use Illuminate\Http\Request;

Route::post('/payment', function(Request $request) {
    $method = $request->input('payment_method');
    
    if ($method == 'qris') {
        $qris = new Qris();
        $qris->processPayment($request->all());
    } elseif ($method == 'ewallet') {
        $ewallet = new Ewallet();
        $ewallet->processPayment($request->all());
    } else {
        // Logika untuk metode pembayaran lainnya (misalnya PayPal)
    }
    
    return redirect('/billing')->with('status', 'Pembayaran berhasil!');
});
